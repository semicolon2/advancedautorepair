<div class="form-group">
	<?php echo $form->label('label', t('Label'))?>
    <?php echo $form->text('label', $label)?>
</div>